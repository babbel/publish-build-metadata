# Dummy project

# Examples

```sh
sudo apt install build-artifacts-collector
build-artifacts-collector
```
